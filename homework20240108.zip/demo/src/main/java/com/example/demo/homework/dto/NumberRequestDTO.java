package com.example.demo.homework.dto;

import lombok.Data;

@Data
public class NumberRequestDTO {
    private String number;
}
