package com.example.demo.homework.service;

import org.springframework.stereotype.Component;

@Component
public interface GuessHistoryerService {
}
