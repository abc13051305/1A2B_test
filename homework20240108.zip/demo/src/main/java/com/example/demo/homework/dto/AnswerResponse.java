package com.example.demo.homework.dto;

import lombok.Data;

@Data
public class AnswerResponse {
    private String message;
}
