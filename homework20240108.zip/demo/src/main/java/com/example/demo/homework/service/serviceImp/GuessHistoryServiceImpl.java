package com.example.demo.homework.service.serviceImp;

import com.example.demo.homework.service.GuessHistoryerService;
import org.springframework.stereotype.Service;

@Service
public class GuessHistoryServiceImpl implements GuessHistoryerService {
}
