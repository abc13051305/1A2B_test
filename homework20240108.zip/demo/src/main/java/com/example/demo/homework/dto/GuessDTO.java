package com.example.demo.homework.dto;

import lombok.Data;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
public class GuessDTO {
    private String guesserId;
    private String number;
}

